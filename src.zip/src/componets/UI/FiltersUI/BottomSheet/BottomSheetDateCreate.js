import React, { useState } from 'react'
import { StyleSheet, View, Text, TouchableOpacity, TextInput } from 'react-native'
import { CalendarList } from 'react-native-calendars'
import { LocaleConfig } from 'react-native-calendars'
import Locacles from '../../../../utils/LocaleConfig'
LocaleConfig.locales['ru'] = Locacles.ru

LocaleConfig.defaultLocale = 'ru'

function BottomSheetDateCreate({ handleClosePress, setPorts }) {
  const [value, setValue] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [startDateTime, setStartDateTime] = useState('')
  const [endDateTime, setEndDateTime] = useState('')
  const [markedDates, setMarkedDates] = useState({})
  const start = new Date(startDateTime)
  const end = new Date(endDateTime)

  const handleDayPress = date => {
    if (!startDate || (startDate && endDate)) {
      // если начальная дата не выбрана или диапазон уже выбран
      setStartDate(date.dateString)
      setStartDateTime(date.timestamp)
      setEndDate('')
      setMarkedDates({
        [date.dateString]: { color: '#FFF1CC', textColor: '#0F1218', startingDay: true },
      })
    } else {
      // если выбрана начальная дата
      let range = {}
      let start = new Date(startDate)
      let end = new Date(date.dateString)
      while (start <= end) {
        let d = new Date(start)
        if (start.getTime() === new Date(startDate).getTime()) {
          // проверяем, является ли текущая дата начальной датой
          range[d.toISOString().slice(0, 10)] = {
            color: '#FFF1CC',
            textColor: '#0F1218',
            startingDay: true,
          }
        } else if (start == end) {
          range[d.toISOString().slice(0, 10)] = {
            color: 'red',
            textColor: '#0F1218',
            endingDay: true,
          }
        } else {
          range[d.toISOString().slice(0, 10)] = { color: '#FFF1CC', textColor: '#0F1218' }
        }
        start.setDate(start.getDate() + 1)
      }
      setStartDate('')
      setEndDate(date.dateString)
      setEndDateTime(date.timestamp)
      setMarkedDates(range)
    }
  }
  console.log(markedDates)
  const handlePress = () => {
    handleClosePress()
    value.length > 0 &&
      setPorts(prevState =>
        prevState.includes(value) ? prevState.filter(id => id !== value) : prevState.concat(String(value)),
      )
  }
  return (
    <View style={styles.container}>
      <View style={styles.topContainer}>
        <Text style={styles.dateCreate}>Дата создания</Text>
        <TextInput textContentType="date" style={styles.topInput} value={123} onChangeText={setValue} />
      </View>
      <View style={styles.calendarContainer}>
        <CalendarList
          hideExtraDays={false}
          firstDay={1}
          markedDates={markedDates}
          onDayPress={handleDayPress}
          markingType="period"
          dayComponent={({ date, state }) => {
            console.log('stete', state)
            return (
              <View>
                <Text style={{ textAlign: 'center', color: state === 'disabled' ? 'gray' : 'black' }}>{date.day}</Text>
              </View>
            )
          }}
          theme={{
            textDisabledColor: 'white',
            textDayFontWeight: 'bold',
            dayTextColor: '#FFFFFF',
            textDayFontSize: 14,
            backgroundColor: '#ffffff',
            selectedDayTextColor: '#0F1218',
            calendarBackground: 'rgba(255, 255, 255, 0.04)',
            monthTextColor: 'white',
            textSectionTitleDisabledColor: '#d9e1e8',
            ['stylesheet.calendar.header']: {
              monthText: {
                fontWeight: '600',
                fontSize: 16,
                lineHeight: 15,
                color: 'white',
              },
              header: {
                flexDirection: 'row',
                paddingLeft: 10,
                paddingRight: 0,
                marginTop: 6,
                alignItems: 'center',
              },
              week: {
                marginTop: 7,
                backgroundColor: 'rgba(255, 255, 255, 0.04)',
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
                paddingLeft: 20,
                paddingRight: 20,
                borderTopLeftRadius: 14,
                borderTopRightRadius: 14,
              },
              dayHeader: {
                color: 'rgba(255, 255, 255, 0.8)',
                display: 'flex',
                flexDirection: 'row',
                fontWeight: '700',
                lineHeight: 15,
                fontSize: 13,
                height: 32,
                textAlign: 'center',
                paddingTop: 17,
                paddingBottom: 24,
              },
            },
            ['stylesheet.calendar.main']: {
              container: {
                paddingLeft: 200,
                paddingRight: 200,
              },
            },
          }}
        />
      </View>
      <TouchableOpacity style={styles.bottomButton} onPress={handlePress} activeOpacity={0.8}>
        <Text style={styles.bottomButtonText}>Добавить</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    height: '100%',
    backgroundColor: '#0F1218',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  topContainer: {
    width: '100%',
  },
  topInput: {
    backgroundColor: '#1E2127',
    color: 'white',
    height: 44,
    marginBottom: 14,
    borderRadius: 8,
    borderWidth: 1,
    paddingLeft: 20,
    paddingTop: 14,
    paddingBottom: 14,
    borderColor: '#333842',
    marginHorizontal: 20,
  },
  calendarContainer: {
    height: '50%',
    width: '100%',
  },
  bottomButton: {
    paddingTop: 18,
    paddingBottom: 18,
    backgroundColor: '#1E2127',
    width: '90%',
    marginBottom: 33,
    borderRadius: 12,
    alignItems: 'center',
  },
  bottomButtonText: {
    color: '#FAC637',
    fontWeight: '600',
    fontSize: 12,
    lineHeight: 15,
  },
  dateCreate: {
    marginTop: 33,
    marginLeft: 20,
    marginBottom: 14,
    fontSize: 16,
    color: 'white',
  },
})

export default BottomSheetDateCreate
