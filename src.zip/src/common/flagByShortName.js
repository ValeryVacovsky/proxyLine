/* eslint-disable react/react-in-jsx-scope */
import FlagAd from '../image/Svg/flags/FlagAd'
import FlagAe from '../image/Svg/flags/FlagAe'
import FlagAf from '../image/Svg/flags/FlagAf'
import FlagAg from '../image/Svg/flags/FlagAg'
import FlagAi from '../image/Svg/flags/FlagAi'
import FlagAl from '../image/Svg/flags/FlagAl'
import FlagAm from '../image/Svg/flags/FlagAm'
import FlagAo from '../image/Svg/flags/FlagAo'
import FlagAq from '../image/Svg/flags/FlagAq'
import FlagAr from '../image/Svg/flags/FlagAr'
import FlagAs from '../image/Svg/flags/FlagAs'
import FlagAt from '../image/Svg/flags/FlagAt'
import FlagAu from '../image/Svg/flags/FlagAu'
import FlagAw from '../image/Svg/flags/FlagAw'
import FlagAx from '../image/Svg/flags/FlagAx'
import FlagAz from '../image/Svg/flags/FlagAz'
import FlagBa from '../image/Svg/flags/FlagBa'
import FlagBb from '../image/Svg/flags/FlagBb'
import FlagBd from '../image/Svg/flags/FlagBd'
import FlagBe from '../image/Svg/flags/FlagBe'
import FlagBf from '../image/Svg/flags/FlagBf'
import FlagBg from '../image/Svg/flags/FlagBg'
import FlagBh from '../image/Svg/flags/FlagBh'
import FlagBi from '../image/Svg/flags/FlagBi'
import FlagBl from '../image/Svg/flags/FlagBl'
import FlagBm from '../image/Svg/flags/FlagBm'
import FlagBn from '../image/Svg/flags/FlagBn'
import FlagBo from '../image/Svg/flags/FlagBo'
import FlagBq from '../image/Svg/flags/FlagBq'
import FlagBr from '../image/Svg/flags/FlagBr'
import FlagBs from '../image/Svg/flags/FlagBs'
import FlagBt from '../image/Svg/flags/FlagBt'
import FlagBv from '../image/Svg/flags/FlagBv'
import FlagBw from '../image/Svg/flags/FlagBw'
import FlagBy from '../image/Svg/flags/FlagBy'
import FlagBz from '../image/Svg/flags/FlagBz'
import FlagCa from '../image/Svg/flags/FlagCa'
import FlagCc from '../image/Svg/flags/FlagCc'
import FlagCd from '../image/Svg/flags/FlagCd'
import FlagCf from '../image/Svg/flags/FlagCf'
import FlagCh from '../image/Svg/flags/FlagCh'
import FlagCi from '../image/Svg/flags/FlagCi'
import FlagCk from '../image/Svg/flags/FlagCk'
import FlagCl from '../image/Svg/flags/FlagCl'
import FlagCm from '../image/Svg/flags/FlagCm'
import FlagCn from '../image/Svg/flags/FlagCn'
import FlagCo from '../image/Svg/flags/FlagCo'
import FlagCq from '../image/Svg/flags/FlagCq'
import FlagCr from '../image/Svg/flags/FlagCr'
import FlagCu from '../image/Svg/flags/FlagCu'
import FlagCv from '../image/Svg/flags/FlagCv'
import FlagCw from '../image/Svg/flags/FlagCw'
import FlagCx from '../image/Svg/flags/FlagCx'
import FlagCy from '../image/Svg/flags/FlagCy'
import FlagCz from '../image/Svg/flags/FlagCz'
import FlagDe from '../image/Svg/flags/FlagDe'
import FlagDj from '../image/Svg/flags/FlagDj'
import FlagDk from '../image/Svg/flags/FlagDk'
import FlagDm from '../image/Svg/flags/FlagDm'
import FlagDz from '../image/Svg/flags/FlagDz'
import FlagEc from '../image/Svg/flags/FlagEc'
import FlagEe from '../image/Svg/flags/FlagEe'
import FlagEg from '../image/Svg/flags/FlagEg'
import FlagEh from '../image/Svg/flags/FlagEh'
import FlagEr from '../image/Svg/flags/FlagEr'
import FlagEs from '../image/Svg/flags/FlagEs'
import FlagEt from '../image/Svg/flags/FlagEt'
import FlagEu from '../image/Svg/flags/FlagEu'
import FlagFi from '../image/Svg/flags/FlagFi'
import FlagFj from '../image/Svg/flags/FlagFj'
import FlagFk from '../image/Svg/flags/FlagFk'
import FlagFm from '../image/Svg/flags/FlagFm'
import FlagFo from '../image/Svg/flags/FlagFo'
import FlagFr from '../image/Svg/flags/FlagFr'
import FlagGa from '../image/Svg/flags/FlagGa'
import FlagGb from '../image/Svg/flags/FlagGb'
import FlagGh from '../image/Svg/flags/FlagGh'
import FlagGi from '../image/Svg/flags/FlagGi'
import FlagGl from '../image/Svg/flags/FlagGl'
import FlagGm from '../image/Svg/flags/FlagGm'
import FlagGn from '../image/Svg/flags/FlagGn'
import FlagGp from '../image/Svg/flags/FlagGp'
import FlagGq from '../image/Svg/flags/FlagGq'
import FlagGr from '../image/Svg/flags/FlagGr'
import FlagGs from '../image/Svg/flags/FlagGs'
import FlagGt from '../image/Svg/flags/FlagGt'
import FlagGu from '../image/Svg/flags/FlagGu'
import FlagGw from '../image/Svg/flags/FlagGw'
import FlagGy from '../image/Svg/flags/FlagGy'
import FlagHk from '../image/Svg/flags/FlagHk'
import FlagHm from '../image/Svg/flags/FlagHm'
import FlagHn from '../image/Svg/flags/FlagHn'
import FlagHr from '../image/Svg/flags/FlagHr'
import FlagHt from '../image/Svg/flags/FlagHt'
import FlagHu from '../image/Svg/flags/FlagHu'
import FlagId from '../image/Svg/flags/FlagId'
import FlagIe from '../image/Svg/flags/FlagIe'
import FlagIl from '../image/Svg/flags/FlagIl'
import FlagIm from '../image/Svg/flags/FlagIm'
import FlagIn from '../image/Svg/flags/FlagIn'
import FlagIo from '../image/Svg/flags/FlagIo'
import FlagIq from '../image/Svg/flags/FlagIq'
import FlagIr from '../image/Svg/flags/FlagIr'
import FlagIs from '../image/Svg/flags/FlagIs'
import FlagIt from '../image/Svg/flags/FlagIt'
import FlagJe from '../image/Svg/flags/FlagJe'
import FlagJm from '../image/Svg/flags/FlagJm'
import FlagJo from '../image/Svg/flags/FlagJo'
import FlagJp from '../image/Svg/flags/FlagJp'
import FlagKe from '../image/Svg/flags/FlagKe'
import FlagKg from '../image/Svg/flags/FlagKg'
import FlagKh from '../image/Svg/flags/FlagKh'
import FlagKi from '../image/Svg/flags/FlagKi'
import FlagKm from '../image/Svg/flags/FlagKm'
import FlagKn from '../image/Svg/flags/FlagKn'
import FlagKp from '../image/Svg/flags/FlagKp'
import FlagRu from '../image/Svg/flags/FlagRu'
import FlagUs from '../image/Svg/flags/FlagUs'

export const flagByShortName = {
  ad: <FlagAd />,
  ae: <FlagAe />,
  af: <FlagAf />,
  ag: <FlagAg />,
  ai: <FlagAi />,
  al: <FlagAl />,
  am: <FlagAm />,
  ao: <FlagAo />,
  aq: <FlagAq />,
  ar: <FlagAr />,
  as: <FlagAs />,
  at: <FlagAt />,
  au: <FlagAu />,
  aw: <FlagAw />,
  ax: <FlagAx />,
  az: <FlagAz />,
  ba: <FlagBa />,
  bb: <FlagBb />,
  bd: <FlagBd />,
  be: <FlagBe />,
  bf: <FlagBf />,
  bg: <FlagBg />,
  bh: <FlagBh />,
  bi: <FlagBi />,
  bl: <FlagBl />,
  bm: <FlagBm />,
  bn: <FlagBn />,
  bo: <FlagBo />,
  bq: <FlagBq />,
  br: <FlagBr />,
  bs: <FlagBs />,
  bt: <FlagBt />,
  bv: <FlagBv />,
  bw: <FlagBw />,
  by: <FlagBy />,
  bz: <FlagBz />,
  ca: <FlagCa />,
  cc: <FlagCc />,
  cd: <FlagCd />,
  cf: <FlagCf />,
  ch: <FlagCh />,
  ci: <FlagCi />,
  ck: <FlagCk />,
  cl: <FlagCl />,
  cm: <FlagCm />,
  cn: <FlagCn />,
  co: <FlagCo />,
  cq: <FlagCq />,
  cr: <FlagCr />,
  cu: <FlagCu />,
  cv: <FlagCv />,
  cw: <FlagCw />,
  cx: <FlagCx />,
  cy: <FlagCy />,
  cz: <FlagCz />,
  de: <FlagDe />,
  dj: <FlagDj />,
  dk: <FlagDk />,
  dm: <FlagDm />,
  dz: <FlagDz />,
  ec: <FlagEc />,
  ee: <FlagEe />,
  eg: <FlagEg />,
  en: <FlagUs />,
  eh: <FlagEh />,
  er: <FlagEr />,
  es: <FlagEs />,
  et: <FlagEt />,
  eu: <FlagEu />,
  fi: <FlagFi />,
  fj: <FlagFj />,
  fk: <FlagFk />,
  fm: <FlagFm />,
  fo: <FlagFo />,
  fr: <FlagFr />,
  ga: <FlagGa />,
  gb: <FlagGb />,
  gh: <FlagGh />,
  gi: <FlagGi />,
  gl: <FlagGl />,
  gm: <FlagGm />,
  gn: <FlagGn />,
  gp: <FlagGp />,
  gq: <FlagGq />,
  gt: <FlagGr />,
  gs: <FlagGs />,
  gt: <FlagGt />,
  gu: <FlagGu />,
  gw: <FlagGw />,
  gy: <FlagGy />,
  hk: <FlagHk />,
  hm: <FlagHm />,
  hn: <FlagHn />,
  hr: <FlagHr />,
  ht: <FlagHt />,
  hu: <FlagHu />,
  id: <FlagId />,
  ie: <FlagIe />,
  il: <FlagIl />,
  im: <FlagIm />,
  in: <FlagIn />,
  io: <FlagIo />,
  iq: <FlagIq />,
  ir: <FlagIr />,
  is: <FlagIs />,
  it: <FlagIt />,
  je: <FlagJe />,
  jm: <FlagJm />,
  jo: <FlagJo />,
  jp: <FlagJp />,
  ke: <FlagKe />,
  kg: <FlagKg />,
  kh: <FlagKh />,
  ki: <FlagKi />,
  km: <FlagKm />,
  kn: <FlagKn />,
  kp: <FlagKp />,
  ru: <FlagRu />,
  us: <FlagUs />,
}
