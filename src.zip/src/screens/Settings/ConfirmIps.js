import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native'
import LayoutMain from '../../componets/LayoutMain'
import { ScrollView, TextInput } from 'react-native-gesture-handler'
import DeleteToggleIcon from '../../image/Svg/DeleteToggleIcon'
import { useCreateIps } from '../../hooks/useCreateIps'
import HeaderTintBack from '../../image/Svg/HeaderTintBack'

function ConfirmIps({ navigation }) {
  const { setDeleteIps, setCreateIps } = useCreateIps()
  const ipsList = useSelector(data => data.ipsTagsReducer.ips)
  const text = useSelector(res => res.textReducer.settings.payload)
  const [value, setValue] = useState('')

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <TouchableOpacity onPress={navigation.goBack} style={styles.headerLeftTintContainer}>
          <HeaderTintBack style={{ bottom: 1 }} />
          <Text style={styles.headerLeftTintText}> Настройки</Text>
        </TouchableOpacity>
      ),
    })
  }, [navigation])

  const handleAddTag = () => {
    if (value.length > 0) {
      setCreateIps({
        ip: value,
        name: 'string',
      })
      setValue('')
    }
  }
  return (
    <LayoutMain style={styles.layoutContainer}>
      <View style={styles.container}>
        <ScrollView style={styles.scrollContainer}>
          <View style={styles.topContainer}>
            {ipsList.map(item => {
              return (
                <TouchableOpacity style={styles.topTextContainer} key={item.id} onPress={() => setDeleteIps(item.id)}>
                  <DeleteToggleIcon />
                  <Text style={styles.ipText}>{item.value}</Text>
                </TouchableOpacity>
              )
            })}
          </View>
        </ScrollView>
        <View style={styles.bottomContainer}>
          <View>
            <Text style={{ color: '#CBCBCB' }}>{text?.texts?.t26}</Text>
          </View>
          <Text style={styles.careText}>{text?.texts?.t27}</Text>
          <TextInput style={styles.input} value={value} onChangeText={setValue} />
          <TouchableOpacity style={styles.bottomTextContainer} onPress={handleAddTag}>
            <Text style={styles.bottomText}>{text?.buttons?.b1}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </LayoutMain>
  )
}

const styles = StyleSheet.create({
  layoutContainer: {
    width: '100%',
  },
  container: {
    display: 'flex',
    marginHorizontal: 20,
    flexDirection: 'column',
    justifyContent: 'space-between',
    height: '100%',
  },
  scrollContainer: {
    width: '100%',
    marginTop: 24,
  },
  topContainer: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  topTextContainer: {
    paddingTop: 8,
    paddingBottom: 8,
    paddingLeft: 12,
    paddingRight: 12,
    display: 'flex',
    flexDirection: 'row',
    backgroundColor: '#333842',
    borderRadius: 30,
    marginRight: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  ipText: {
    color: 'white',
    fontWeight: '400',
    fontSize: 13,
    lineHeight: 15,
    marginLeft: 9,
  },
  bottomContainer: {
    width: '100%',
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#1E2127',
    paddingHorizontal: 10,
    paddingVertical: 15,
    color: 'white',
    fontWeight: '600',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333842',
    marginTop: 14,
  },
  bottomTextContainer: {
    backgroundColor: '#FAC637',
    width: '100%',
    height: 50,
    borderRadius: 12,
    marginTop: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomText: {
    color: '#0F1218',
    fontWeight: '600',
    fontSize: 13,
    lineHeight: 15,
  },
  headerLeftTintContainer: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLeftTintText: {
    color: '#CBCBCB',
    fontWeight: '600',
    fontSize: 14,
    lineHeight: 15,
  },
  careText: {
    color: '#EC3641',
    fontSize: 13,
    lineHeight: 15,
    marginTop: 20,
    fontWeight: '400',
  },
})

export default ConfirmIps
