export const Colors = {
  red: {
    back: 'rgba(236, 54, 65, 0.1)',
    color: '#EC3641',
  },
  orange: {
    back: 'rgba(246, 186, 64, 0.1)',
    color: '#F6BA40',
  },
  green: {
    back: 'rgba(97, 198, 123, 0.1)',
    color: '#61C67B',
  },
  blue: {
    back: 'rgba(35, 107, 246, 0.1)',
    color: '#236BF6',
  },
}
